create procedure sp_transfer_money(IN sender_id integer, IN receiver_id integer, IN transfer_amount integer, OUT status character varying)
    language plpgsql
as
$$
    DECLARE
        sender_amount int;
        receiver_amount int;
        temp_value int;
    BEGIN
        SELECT bgn FROM bank WHERE id = sender_id INTO sender_amount;
        IF sender_amount < transfer_amount THEN
            status:= 'The sender does not have enough money';
            RETURN;
        END IF;
        SELECT bgn FROM BANK WHERE id= receiver_id INTO receiver_amount;
        UPDATE bank SET bgn = bgn + transfer_amount WHERE id = receiver_id;
        UPDATE bank SET bgn = bgn - transfer_amount WHERE id = sender_id;
        SELECT bgn FROM bank WHERE id = sender_id INTO temp_value;
        IF sender_amount - transfer_amount <> temp_value THEN
            status := 'Error when transfer from sender';
            ROLLBACK;
            RETURN;
        END IF;
        SELECT bgn FROM bank WHERE id = receiver_id INTO temp_value;
        IF receiver_amount + transfer_amount <> temp_value THEN
            status := 'Error when transfer to receiver';
            ROLLBACK;
            RETURN;
        END IF;
        status := 'Success';
        COMMIT;
    END
$$;

alter procedure sp_transfer_money(integer, integer, integer, out varchar) owner to postgres;

