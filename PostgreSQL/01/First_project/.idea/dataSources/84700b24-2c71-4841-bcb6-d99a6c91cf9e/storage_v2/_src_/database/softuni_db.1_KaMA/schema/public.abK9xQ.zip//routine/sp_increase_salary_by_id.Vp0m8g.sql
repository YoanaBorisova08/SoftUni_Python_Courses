create procedure sp_increase_salary_by_id(IN id integer)
    language plpgsql
as
$$
    DECLARE
        employee INT;
    BEGIN
        IF (SELECT employee_id FROM employees WHERE employee_id = id) IS NULL
            THEN ROLLBACK ;
        END IF;
        UPDATE employees
        SET salary = salary * 1.05
        WHERE
            employee_id = id;
        COMMIT;

    END
$$;

alter procedure sp_increase_salary_by_id(integer) owner to postgres;

