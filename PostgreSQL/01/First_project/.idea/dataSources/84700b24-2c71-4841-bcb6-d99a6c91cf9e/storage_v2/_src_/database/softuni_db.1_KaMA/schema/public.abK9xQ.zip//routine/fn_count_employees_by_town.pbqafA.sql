create function fn_count_employees_by_town(town_name character varying) returns integer
    language plpgsql
as
$$
    DECLARE id INT;
    BEGIN
        SELECT town_id FROM towns as t WHERE t.name = town_name INTO id;
        RETURN (SELECT count(*)
                FROM employees AS e
                         JOIN addresses AS a USING (address_id)
                         JOIN towns as t USING (town_id)
                WHERE t.town_id = id);
    END
$$;

alter function fn_count_employees_by_town(varchar) owner to postgres;

