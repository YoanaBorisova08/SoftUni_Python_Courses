create view view_performance_rating (first_name, last_name, job_title, salary, department_id, performance_rating) as
SELECT first_name,
       last_name,
       job_title,
       salary,
       department_id,
       CASE
           WHEN salary >= 25000::numeric AND job_title::text ~~ 'Senior%'::text THEN 'High-performing Senior'::text
           WHEN salary >= 25000::numeric THEN 'High-performing Employee'::text
           ELSE 'Average-performing'::text
           END AS performance_rating
FROM employees;

alter table view_performance_rating
    owner to postgres;

