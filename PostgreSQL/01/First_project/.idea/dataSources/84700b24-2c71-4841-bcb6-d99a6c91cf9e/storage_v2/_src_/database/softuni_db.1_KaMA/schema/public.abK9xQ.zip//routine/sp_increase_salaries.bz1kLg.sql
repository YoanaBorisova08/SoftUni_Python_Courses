create procedure sp_increase_salaries(IN department_name character varying)
    language plpgsql
as
$$
    DECLARE
        id INT;
    BEGIN
        SELECT department_id FROM departments WHERE name = department_name INTO id;
        UPDATE employees
        SET salary = salary * 1.05
        WHERE department_id = id ;
    END
$$;

alter procedure sp_increase_salaries(varchar) owner to postgres;

