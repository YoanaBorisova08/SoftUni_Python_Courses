create function fn_get_initials(first_name character varying, last_name character varying) returns character varying
    language plpgsql
as
$$
    BEGIN
        RETURN concat(left(first_name, 1), '.', left(last_name, 1), '.');
    END
$$;

alter function fn_get_initials(varchar, varchar) owner to postgres;

