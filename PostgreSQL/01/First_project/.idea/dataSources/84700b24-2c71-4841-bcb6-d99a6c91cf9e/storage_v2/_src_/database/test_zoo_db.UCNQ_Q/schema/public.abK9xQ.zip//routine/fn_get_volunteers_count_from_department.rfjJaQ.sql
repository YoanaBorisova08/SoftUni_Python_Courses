create function fn_get_volunteers_count_from_department(searched_volunteers_department character varying) returns integer
    language plpgsql
as
$$
    BEGIN
        RETURN (SELECT COUNT(*)
                FROM volunteers_departments as vd
                JOIN volunteers as v ON v.department_id = vd.id
                WHERE department_name=searched_volunteers_department);
    END
$$;

alter function fn_get_volunteers_count_from_department(varchar) owner to postgres;

