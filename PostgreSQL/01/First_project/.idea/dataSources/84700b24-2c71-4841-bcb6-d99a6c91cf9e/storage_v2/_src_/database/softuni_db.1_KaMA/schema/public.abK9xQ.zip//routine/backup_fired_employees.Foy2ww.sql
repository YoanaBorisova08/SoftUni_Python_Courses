create function backup_fired_employees() returns trigger
    language plpgsql
as
$$
    BEGIN
        INSERT INTO deleted_employees
        VALUES (
                   old.employee_id,
                   old.first_name,
                   old.last_name,
                   old.middle_name,
                   old.job_title,
                   old.department_id,
                   old.salary
        );
        RETURN old;
    END
$$;

alter function backup_fired_employees() owner to postgres;

