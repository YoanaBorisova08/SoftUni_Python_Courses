create function fn_calculate_future_value(initial_sum numeric, yearly_interest_rate numeric, number_of_years integer) returns numeric
    language plpgsql
as
$$
    BEGIN
        RETURN TRUNC(initial_sum*POWER(1+yearly_interest_rate, number_of_years), 4);
    END
$$;

alter function fn_calculate_future_value(numeric, numeric, integer) owner to postgres;

