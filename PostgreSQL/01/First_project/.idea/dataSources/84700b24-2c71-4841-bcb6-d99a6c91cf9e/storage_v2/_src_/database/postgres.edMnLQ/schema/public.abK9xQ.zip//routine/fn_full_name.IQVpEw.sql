create function fn_full_name(first_name character varying, last_name character varying) returns character varying
    language plpgsql
as
$$
    DECLARE
        full_name VARCHAR(101);
    BEGIN
        full_name := CONCAT(INITCAP(LOWER(first_name)), ' ', INITCAP(LOWER(last_name)));
        RETURN full_name;
    END
$$;

alter function fn_full_name(varchar, varchar) owner to postgres;

