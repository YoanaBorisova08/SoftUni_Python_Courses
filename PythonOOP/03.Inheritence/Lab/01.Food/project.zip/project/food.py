class Food:
    def __init__(self, date: str):
        self.expiration_date = date
